const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../.env') });
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const siteConfig = require('./config/site');
const donations = require('./routes/donations');
const Donation = require('./models/Donation');

const app = express();
app.use(cors({ origin: process.env.CLIENT_URL || true }));

// Webhook needs the raw body for signature checking, so register it before express.json()
app.post('/api/webhook/razorpay', express.raw({ type: '*/*' }), donations.webhook);
app.use(express.json());

app.get('/api/config', (_req, res) => res.json(siteConfig()));
app.use('/api/donations', donations);

app.get('/api/admin/donations', async (req, res) => {
  if (!process.env.ADMIN_KEY || req.headers['x-admin-key'] !== process.env.ADMIN_KEY) return res.sendStatus(401);
  res.json(await Donation.find().sort({ createdAt: -1 }).limit(500));
});

// Serve the built React app in production
const dist = path.join(__dirname, '../client/dist');
app.use(express.static(dist));
app.get('*', (req, res, next) =>
  req.path.startsWith('/api') ? next() : res.sendFile(path.join(dist, 'index.html'), (err) => err && next())
);

const port = process.env.PORT || 5000;
mongoose.set('bufferCommands', false);
mongoose
  .connect(process.env.MONGO_URI, { serverSelectionTimeoutMS: 3000 })
  .catch((err) => console.error('MongoDB connection failed (donations will not save):', err.message))
  .finally(() => app.listen(port, () => console.log(`API running on http://localhost:${port}`)));

// Don't let a failed DB call take the whole server down
process.on('unhandledRejection', (err) => console.error('Unhandled:', err.message));
