const e = process.env;

// Everything the front-end displays comes from here, so renaming is just editing .env.
module.exports = () => ({
  orgName: e.ORG_NAME || 'Your Charity Name',
  tagline: e.ORG_TAGLINE || '',
  logoText: e.ORG_LOGO_TEXT || 'DN',
  email: e.ORG_EMAIL || '',
  phone: e.ORG_PHONE || '',
  address: e.ORG_ADDRESS || '',
  reg80g: e.ORG_REG_80G || '',
  primaryColor: e.ORG_PRIMARY_COLOR || '#e4572e',
  heroImage: e.ORG_HERO_IMAGE || '',
  campaignTitle: e.CAMPAIGN_TITLE || 'Donate',
  campaignDescription: e.CAMPAIGN_DESCRIPTION || '',
  razorpayKeyId: e.RAZORPAY_KEY_ID || '',
  presetAmounts: [500, 1000, 2500, 5000, 10000],
  causes: [
    { id: 'meals', title: 'Feed a patient', amount: 500, note: 'Nutritious meals for a week' },
    { id: 'medicine', title: 'Medicines', amount: 2500, note: 'Supports a month of medicines' },
    { id: 'stay', title: 'Shelter for family', amount: 5000, note: 'A month of safe stay near hospital' },
  ],
});
