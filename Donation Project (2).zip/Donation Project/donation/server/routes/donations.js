const express = require('express');
const crypto = require('crypto');
const Razorpay = require('razorpay');
const Donation = require('../models/Donation');

const router = express.Router();

const razorpay = () =>
  new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET });

const receiptNo = () => `RCPT-${new Date().getFullYear()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;

const safeEqual = (a, b) => a.length === b.length && crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));

// Step 1: validate donor details, create a Razorpay order
router.post('/order', async (req, res) => {
  try {
    const { name, email, phone, pan, address, amount, cause, anonymous } = req.body;
    const amt = Number(amount);
    const digits = String(phone || '').replace(/\D/g, '').slice(-10);
    if (!name?.trim() || !/^\S+@\S+\.\S+$/.test(email || '') || digits.length !== 10) {
      return res.status(400).json({ message: 'Please enter a valid name, email and 10-digit phone number.' });
    }
    if (!Number.isFinite(amt) || amt < 10 || amt > 1000000) {
      return res.status(400).json({ message: 'Amount must be between ₹10 and ₹10,00,000.' });
    }
    if (pan && !/^[A-Za-z]{5}\d{4}[A-Za-z]$/.test(pan)) {
      return res.status(400).json({ message: 'PAN format looks invalid.' });
    }

    const order = await razorpay().orders.create({
      amount: Math.round(amt * 100), // paise
      currency: 'INR',
      receipt: receiptNo(),
    });

    const donation = await Donation.create({
      name, email, phone: digits, pan, address,
      amount: amt, cause, anonymous: !!anonymous, razorpayOrderId: order.id, receiptNo: order.receipt,
    });

    res.json({ orderId: order.id, amount: order.amount, currency: order.currency, donationId: donation._id });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Could not start payment. Please try again.' });
  }
});

// Step 2: verify the signature returned by Razorpay Checkout
router.post('/verify', async (req, res) => {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;
    if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
      return res.status(400).json({ message: 'Missing payment details.' });
    }
    const expected = crypto
      .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
      .update(`${razorpay_order_id}|${razorpay_payment_id}`)
      .digest('hex');
    if (!safeEqual(expected, String(razorpay_signature))) {
      return res.status(400).json({ message: 'Payment verification failed.' });
    }

    const donation = await Donation.findOneAndUpdate(
      { razorpayOrderId: razorpay_order_id },
      { status: 'paid', razorpayPaymentId: razorpay_payment_id },
      { new: true }
    );
    if (!donation) return res.status(404).json({ message: 'Donation not found.' });
    res.json({ name: donation.name, amount: donation.amount, receiptNo: donation.receiptNo, paymentId: razorpay_payment_id });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Verification error.' });
  }
});

// Public "recent donors" list (names hidden for anonymous donors)
router.get('/recent', async (_req, res) => {
  const list = await Donation.find({ status: 'paid' }).sort({ createdAt: -1 }).limit(8).lean();
  res.json(list.map((d) => ({ name: d.anonymous ? 'Anonymous' : d.name, amount: d.amount, at: d.createdAt })));
});

router.get('/stats', async (_req, res) => {
  const [agg] = await Donation.aggregate([
    { $match: { status: 'paid' } },
    { $group: { _id: null, total: { $sum: '$amount' }, count: { $sum: 1 } } },
  ]);
  res.json({ total: agg?.total || 0, count: agg?.count || 0 });
});

// Webhook (mounted with raw body in index.js): safety net if the donor closes the tab right after paying
router.webhook = async (req, res) => {
  const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
  if (!secret) return res.sendStatus(200);
  const sig = String(req.headers['x-razorpay-signature'] || '');
  const expected = crypto.createHmac('sha256', secret).update(req.body).digest('hex');
  if (!safeEqual(sig, expected)) return res.sendStatus(400);

  const event = JSON.parse(req.body.toString());
  const p = event.payload?.payment?.entity;
  if (event.event === 'payment.captured' && p) {
    await Donation.findOneAndUpdate({ razorpayOrderId: p.order_id }, { status: 'paid', razorpayPaymentId: p.id });
  } else if (event.event === 'payment.failed' && p) {
    await Donation.findOneAndUpdate({ razorpayOrderId: p.order_id, status: 'created' }, { status: 'failed' });
  }
  res.sendStatus(200);
};

module.exports = router;
