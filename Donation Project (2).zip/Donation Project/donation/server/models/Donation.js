const mongoose = require('mongoose');

const donationSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, trim: true, lowercase: true },
    phone: { type: String, required: true, trim: true },
    pan: { type: String, trim: true, uppercase: true },
    address: { type: String, trim: true },
    amount: { type: Number, required: true, min: 1 }, // in rupees
    cause: { type: String, default: 'general' },
    anonymous: { type: Boolean, default: false },
    status: { type: String, enum: ['created', 'paid', 'failed'], default: 'created' },
    razorpayOrderId: { type: String, index: true },
    razorpayPaymentId: String,
    receiptNo: String,
  },
  { timestamps: true }
);

module.exports = mongoose.model('Donation', donationSchema);
