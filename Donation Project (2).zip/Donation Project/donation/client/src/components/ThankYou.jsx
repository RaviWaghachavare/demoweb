import { inr } from '../App.jsx';

export default function ThankYou({ receipt, site, onAgain }) {
  return (
    <div className="thanks">
      <div className="tick">✓</div>
      <h2>Thank you, {receipt.name}!</h2>
      <p>Your donation of <b>{inr(receipt.amount)}</b> to {site.orgName} was received.</p>
      <p className="muted">Receipt no: {receipt.receiptNo}<br />Payment ID: {receipt.paymentId}</p>
      <div className="actions">
        <button className="btn" onClick={() => window.print()}>Print receipt</button>
        <button className="btn btn-ghost" onClick={onAgain}>Donate again</button>
      </div>
    </div>
  );
}
