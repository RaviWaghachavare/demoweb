import { useState } from 'react';
import { inr } from '../App.jsx';

const loadRazorpay = () =>
  new Promise((resolve) => {
    if (window.Razorpay) return resolve(true);
    const s = document.createElement('script');
    s.src = 'https://checkout.razorpay.com/v1/checkout.js';
    s.onload = () => resolve(true);
    s.onerror = () => resolve(false);
    document.body.appendChild(s);
  });

export default function DonateForm({ site, onSuccess }) {
  const [amount, setAmount] = useState(site.presetAmounts[1]);
  const [form, setForm] = useState({ name: '', email: '', phone: '', pan: '', address: '', anonymous: false });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });

  async function submit(e) {
    e.preventDefault();
    setError('');
    if (!amount || Number(amount) < 10) return setError('Minimum donation is ₹10.');
    setBusy(true);
    try {
      if (!(await loadRazorpay())) throw new Error('Could not load the payment window. Check your connection.');

      const res = await fetch('/api/donations/order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, amount: Number(amount) }),
      });
      const order = await res.json();
      if (!res.ok) throw new Error(order.message);

      const rzp = new window.Razorpay({
        key: site.razorpayKeyId,
        amount: order.amount,
        currency: order.currency,
        order_id: order.orderId,
        name: site.orgName,
        description: site.campaignTitle,
        prefill: { name: form.name, email: form.email, contact: form.phone },
        theme: { color: site.primaryColor },
        handler: async (resp) => {
          const v = await fetch('/api/donations/verify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(resp),
          });
          const data = await v.json();
          setBusy(false);
          if (!v.ok) return setError(data.message);
          onSuccess(data);
        },
        modal: { ondismiss: () => setBusy(false) },
      });
      rzp.on('payment.failed', (r) => {
        setBusy(false);
        setError(r.error?.description || 'Payment failed. Please try again.');
      });
      rzp.open();
    } catch (err) {
      setBusy(false);
      setError(err.message);
    }
  }

  return (
    <form onSubmit={submit}>
      <h2>Make a donation</h2>

      <div className="amounts">
        {site.presetAmounts.map((a) => (
          <button type="button" key={a} className={Number(amount) === a ? 'chip on' : 'chip'} onClick={() => setAmount(a)}>
            {inr(a)}
          </button>
        ))}
      </div>

      <label>Or enter amount (₹)
        <input type="number" min="10" value={amount} onChange={(e) => setAmount(e.target.value)} required />
      </label>

      <div className="row">
        <label>Full name *<input value={form.name} onChange={set('name')} required /></label>
        <label>Mobile number *<input value={form.phone} onChange={set('phone')} inputMode="numeric" maxLength={14} required /></label>
      </div>
      <label>Email *<input type="email" value={form.email} onChange={set('email')} required /></label>
      <div className="row">
        <label>PAN (for 80G receipt)<input value={form.pan} onChange={set('pan')} maxLength={10} style={{ textTransform: 'uppercase' }} /></label>
        <label>Address<input value={form.address} onChange={set('address')} /></label>
      </div>

      <label className="check">
        <input type="checkbox" checked={form.anonymous} onChange={set('anonymous')} />
        Hide my name from the public donor list
      </label>

      {error && <p className="error">{error}</p>}

      <button className="btn btn-lg" disabled={busy}>
        {busy ? 'Please wait…' : `Donate ${amount ? inr(amount) : ''}`}
      </button>
    </form>
  );
}
