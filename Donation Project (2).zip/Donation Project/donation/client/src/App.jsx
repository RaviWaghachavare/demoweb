import { useEffect, useState } from 'react';
import DonateForm from './components/DonateForm.jsx';
import ThankYou from './components/ThankYou.jsx';

export const inr = (n) => '₹' + Number(n).toLocaleString('en-IN');

export default function App() {
  const [site, setSite] = useState(null);
  const [stats, setStats] = useState({ total: 0, count: 0 });
  const [recent, setRecent] = useState([]);
  const [receipt, setReceipt] = useState(null);
  const [error, setError] = useState('');

  const loadLive = () => {
    fetch('/api/donations/stats').then((r) => r.json()).then(setStats).catch(() => {});
    fetch('/api/donations/recent').then((r) => r.json()).then(setRecent).catch(() => {});
  };

  useEffect(() => {
    fetch('/api/config')
      .then((r) => r.json())
      .then((c) => {
        setSite(c);
        document.title = `${c.campaignTitle} | ${c.orgName}`;
        document.documentElement.style.setProperty('--brand', c.primaryColor);
      })
      .catch(() => setError('Could not reach the server. Is the API running?'));
    loadLive();
  }, []);

  if (error) return <p className="center-msg">{error}</p>;
  if (!site) return <p className="center-msg">Loading…</p>;

  return (
    <>
      <header className="nav">
        <div className="wrap nav-in">
          <div className="logo">
            <span className="logo-mark">{site.logoText}</span>
            <span>{site.orgName}</span>
          </div>
          <a href="#donate" className="btn btn-sm">Donate now</a>
        </div>
      </header>

      <section className="hero" style={{ backgroundImage: `linear-gradient(rgba(0,0,0,.55),rgba(0,0,0,.55)), url(${site.heroImage})` }}>
        <div className="wrap hero-in">
          <p className="eyebrow">{site.tagline}</p>
          <h1>{site.campaignTitle}</h1>
          <p className="lead">{site.campaignDescription}</p>
          <div className="stats">
            <div><b>{inr(stats.total)}</b><span>raised</span></div>
            <div><b>{stats.count}</b><span>donors</span></div>
          </div>
        </div>
      </section>

      <main className="wrap grid" id="donate">
        <div className="card">
          {receipt ? (
            <ThankYou receipt={receipt} site={site} onAgain={() => setReceipt(null)} />
          ) : (
            <DonateForm site={site} onSuccess={(r) => { setReceipt(r); loadLive(); }} />
          )}
        </div>

        <aside>
          <div className="card">
            <h3>Where your money goes</h3>
            <ul className="causes">
              {site.causes.map((c) => (
                <li key={c.id}>
                  <b>{inr(c.amount)}</b>
                  <div><strong>{c.title}</strong><small>{c.note}</small></div>
                </li>
              ))}
            </ul>
          </div>

          <div className="card">
            <h3>Recent donors</h3>
            {recent.length === 0 && <p className="muted">Be the first to donate.</p>}
            <ul className="recent">
              {recent.map((d, i) => (
                <li key={i}><span>{d.name}</span><b>{inr(d.amount)}</b></li>
              ))}
            </ul>
          </div>

          <div className="card trust">
            <p>🔒 Secure payments via Razorpay (UPI, cards, net banking, wallets)</p>
            {site.reg80g && <p>🧾 {site.reg80g} — donations eligible for tax exemption</p>}
          </div>
        </aside>
      </main>

      <footer className="footer">
        <div className="wrap">
          <strong>{site.orgName}</strong>
          <p>{site.address}</p>
          <p>{[site.email, site.phone].filter(Boolean).join(' · ')}</p>
          <p className="muted">© {new Date().getFullYear()} {site.orgName}. All rights reserved.</p>
        </div>
      </footer>
    </>
  );
}
