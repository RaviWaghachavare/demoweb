# Donation site (MERN + Razorpay)

MongoDB + Express + React (Vite) + Node. Payments via Razorpay (UPI, cards, net banking, wallets).

## Setup
1. Install MongoDB locally (or use a MongoDB Atlas URI).
2. `npm run install:all`
3. Edit `.env` (in the project root): set `MONGO_URI`, your Razorpay `RAZORPAY_KEY_ID` / `RAZORPAY_KEY_SECRET`.
4. `npm run dev` → open http://localhost:5173

## Customising the name / branding
Edit the `ORG_*` and `CAMPAIGN_*` values in `.env` and restart the server. The name, logo letters,
colour, hero image, contact details and campaign text all update on the site. Donation amounts and the
"where your money goes" list are in `server/config/site.js`.

## Production
`npm run build` then `npm start` — Express serves the built React app and the API on one port.
Optional: add a Razorpay webhook to `/api/webhook/razorpay` (events `payment.captured`, `payment.failed`)
and set `RAZORPAY_WEBHOOK_SECRET`.

## Viewing donations
`GET /api/admin/donations` with header `x-admin-key: <ADMIN_KEY>`.
